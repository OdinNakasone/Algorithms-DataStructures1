﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WeightForWeightKata
{
    class Program
    {
        static void Main(string[] args)
        {
           Console.WriteLine(OrderWeight("2000 103 123 4444 99"));
        }

        public static string OrderWeight(string strng)
        {
            return String.Join(" ", strng.Split(' ').OrderBy(w => w).OrderBy(w => w.Sum(c => int.Parse(c.ToString()))));


        }
    }
}
