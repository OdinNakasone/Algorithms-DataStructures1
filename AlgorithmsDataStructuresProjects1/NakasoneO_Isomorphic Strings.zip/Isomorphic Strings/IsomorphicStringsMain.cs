﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace IsomorphicStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Application Start ----------------");
            Console.WriteLine();

            //Read all the lines
            string[] words = File.ReadAllLines("C:/Neumont Year 2/Q3/Algorithms & Data Structures 1/AlgorithmsDataStructures1/Isomorphic Strings/IsomorphInput1.txt");

            Dictionary<string, List<string>> exactIsomorphsDict = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> looseIsomorphsDict = new Dictionary<string, List<string>>();
            

            foreach (string word in words)
            {
                //Exact Isomporh
                string exactIso = ExactIsomorphic(word);
                if (exactIsomorphsDict.ContainsKey(exactIso))
                {
                    exactIsomorphsDict[exactIso].Add(word);
                }
                else
                {
                    exactIsomorphsDict[exactIso] = new List<string>();
                    exactIsomorphsDict[exactIso].Add(word);
                }

                //looseIsomorph
                string looseIso = LooseIsomorphic(word);
                if (looseIsomorphsDict.ContainsKey(looseIso))
                {
                    looseIsomorphsDict[looseIso].Add(word);
                }
                else
                {
                    looseIsomorphsDict[looseIso] = new List<string>();
                    looseIsomorphsDict[looseIso].Add(word);
                }

            }
            //===============RESULT==============//
            StringBuilder exactStringBuilder = new StringBuilder();
            exactStringBuilder.AppendLine("Exact Isomorphs");
            //Exact Isomorph Result
            foreach (KeyValuePair<string, List<string>> pair in exactIsomorphsDict)
            {
                if (pair.Value.Count > 1)
                {
                    pair.Value.Sort();
                    string isomorphsWordsList = string.Join(" ", pair.Value);
                    exactStringBuilder.AppendLine(pair.Key + ": " + isomorphsWordsList);
                }
            }

            exactStringBuilder.AppendLine();

            exactStringBuilder.AppendLine("Loose Isomorphs");
            //Loose Isomporh Result
            foreach (KeyValuePair<string, List<string>> pair in looseIsomorphsDict)
            {
                if (pair.Value.Count > 1)
                {
                    pair.Value.Sort();
                    string isomorphsWordsList = string.Join(" ", pair.Value);
                    exactStringBuilder.AppendLine(pair.Key + ": " + isomorphsWordsList);
                }
            }

            exactStringBuilder.AppendLine();

            exactStringBuilder.AppendLine("Non-isomorphs");
            //Non Isomorphs
            foreach (KeyValuePair<string, List<string>> pair in looseIsomorphsDict)
            {
                if (pair.Value.Count == 1)
                {
                    pair.Value.Sort();
                    string isomorphsWordsList = string.Join(" ", pair.Value);
                    exactStringBuilder.Append(isomorphsWordsList + " ");
                }
            }
            Console.WriteLine(exactStringBuilder.ToString());

            WriteFile(exactStringBuilder.ToString());
        }

        private static void WriteFile(string text)
        {
            File.WriteAllText("C:/Neumont Year 2/Q3/Algorithms & Data Structures 1/AlgorithmsDataStructures1/Isomorphic Strings/output.txt", text);
        }

        private static string ExactIsomorphic(string word)
        {
            Dictionary<char, int> wordDictionary = new Dictionary<char, int>();
            string isometricString = "";
            int index = -1;
            foreach (char c in word)
            {
                if (wordDictionary.ContainsKey(c))
                {
                    isometricString += wordDictionary[c];
                }
                else
                {
                    index++;
                    wordDictionary[c] = index;
                    isometricString += index;
                }
            }
            return isometricString;
        }

        private static string LooseIsomorphic(string word)
        {
            Dictionary<char, int> wordDictionary = new Dictionary<char, int>();

            foreach (char c in word)
            {
                if (wordDictionary.ContainsKey(c))
                {
                    wordDictionary[c] = wordDictionary[c] + 1;
                }
                else
                {
                    wordDictionary[c] = 1;
                }
            }

            var list = wordDictionary.OrderBy(pair => pair.Value).Select(pair => pair.Value).ToList();
            return string.Join("", list);
        }
    }
}
