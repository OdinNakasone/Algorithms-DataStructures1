﻿using System;

namespace TakeATenMinuteWalkKata
{
    class Program
    {
        static void Main(string[] args)
        {
       
        }

        public static bool IsValidWalk(string[] walk)
        {
            int samePlace = 0;

            bool valid = false;

            if(walk.Length == 10)
            {
                foreach(string direction in walk)
                {
                   switch(direction.ToLower())
                    {
                        case "n":
                            samePlace++;
                            break;

                        case "s":
                            samePlace--;
                            break;

                        case "w":
                            samePlace--;
                            break;

                        case "e":
                            samePlace++;
                            break;
                    }
                }

                if (samePlace == 0)
                {
                    valid = true;
                }
            }

            return valid;
        }

        
    }
}
