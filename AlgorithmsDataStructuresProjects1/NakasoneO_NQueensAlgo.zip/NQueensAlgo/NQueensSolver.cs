﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NQueensAlgo
{
    class NQueensSolver
    {
        public List<List<int>> chessBoard = new List<List<int>>();
        public Dictionary<String, String> solutionsDict = new Dictionary<String, String>();

        public int queenNumber;
        public int steps = 0;

        public NQueensSolver(int n)
        {
            queenNumber = n;
            SolveProblem(n);
        }

        public void SolveProblem(int n)
        {
            //Create board
            for (int i = 0; i < n; i++)
            {
                List<int> row = Enumerable.Repeat(0, n).ToList();
                chessBoard.Add(row);
            }

            PlaceQueen();
            Console.WriteLine("Total Solutions: " + solutionsDict.Count);
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var list in solutionsDict)
            {
                stringBuilder.AppendLine("Solution: found in " + list.Value + " steps.");
                foreach (var val in list.Key)
                {

                    stringBuilder.Append(val);
                }

                stringBuilder.AppendLine();
            }

            Console.WriteLine(stringBuilder.ToString());
        }
        public void PlaceQueen(int nQueen = 0)
        {
            if (queenNumber <= nQueen)
            {
                return;
            }

            for (int i = 0; i < queenNumber; i++)
            {

                steps++;

                if (chessBoard[nQueen][i] != 0)
                {
                    continue;
                }

                chessBoard[nQueen][i] = -1;
                UpdateBoard(nQueen, i, 1);

                if (nQueen == queenNumber - 1)
                {
                    AddBoardToSolutions();
                }
                else
                {
                    PlaceQueen(nQueen + 1);

                }

                chessBoard[nQueen][i] = 0;
                UpdateBoard(nQueen, i, -1);

            }
        }

        public void UpdateBoard(int i, int j, int value)
        {

            for (int k = 0; k < i; k++)
                chessBoard[k][j] += value;

            //down check  
            for (int k = i + 1; k < queenNumber; k++)
                chessBoard[k][j] += value;

            //left check 
            for (int k = 0; k < j; k++)
                chessBoard[i][k] += value;

            //up-left check  
            for (int m = i - 1, n = j - 1; m >= 0 && n >= 0; m--, n--)
                chessBoard[m][n] += value;

            //down-left check  
            for (int m = i + 1, n = j - 1; m < queenNumber && n >= 0; m++, n--)
                chessBoard[m][n] += value;

            //Right check  
            for (int k = j + 1; k < queenNumber; k++)
                chessBoard[i][k] += value;

            //up-right check  
            for (int m = i - 1, n = j + 1; m >= 0 && n < queenNumber; m--, n++)
                chessBoard[m][n] += value;

            //down-right check  
            for (int m = i + 1, n = j + 1; m < queenNumber && n < queenNumber; m++, n++)
                chessBoard[m][n] += value;

        }

        public void AddBoardToSolutions()
        {
            string result = String.Empty;
            for (int k = 0; k < queenNumber; k++)
            {
                string row = string.Empty;
                for (int j = 0; j < queenNumber; j++)
                    row += chessBoard[k][j] == -1 ? "Q" : "-";
                result += row + Environment.NewLine;
            }

            solutionsDict.Add(result, steps.ToString());
            //reset steps
            steps = 0;
        }
    }
}
