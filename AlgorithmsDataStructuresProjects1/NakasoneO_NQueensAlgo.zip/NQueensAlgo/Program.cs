﻿using System;

namespace NQueensAlgo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a dimension for a chess board");
            string num = Console.ReadLine();
            int parseNum = int.Parse(num);
            Console.WriteLine($"n={parseNum}");
            _ = new NQueensSolver(parseNum);

        }
    }
}
