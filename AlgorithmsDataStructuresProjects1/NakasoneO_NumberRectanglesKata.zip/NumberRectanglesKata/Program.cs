﻿using System;

namespace NumberRectanglesKata
{
    class Program
    {
        static void Main(string[] args)
        {
            bool check1 = 18 == NumberOfRectangles(3, 2);
            Console.WriteLine(check1);

            bool check2 = 225 == NumberOfRectangles(5, 5);
            Console.WriteLine(check2);
        }

        public static int NumberOfRectangles(int m, int n)
        {
            return (m * (m + 1) * n * (n + 1)) / 4;
        }
    }
}
